import os

# 获取当前目录下的所有文件夹
folders = [folder for folder in os.listdir() if os.path.isdir(folder)]

# 遍历每个文件夹
for folder in folders:
    # 构建ID文件的路径
    id_file_path = os.path.join(folder, 'ID')
    phases_file_path = os.path.join(folder, 'phases.c')
    solution_file_path = os.path.join(folder, 'solution.txt')
    
    # 删除指定文件
    if os.path.exists(id_file_path):
        os.remove(id_file_path)
    if os.path.exists(phases_file_path):
        os.remove(phases_file_path)
    if os.path.exists(solution_file_path):
        os.remove(solution_file_path)

