import os

# 获取当前目录下的所有文件夹
folders = [folder for folder in os.listdir() if os.path.isdir(folder)]

# 遍历每个文件夹
for folder in folders:
    # 构建ID文件的路径
    id_file_path = os.path.join(folder, 'ID')
    
    # 检查ID文件是否存在
    if os.path.isfile(id_file_path):
        # 读取ID文件中的内容
        with open(id_file_path, 'r') as f:
            id_content = f.read().strip()
        
        # 构建新文件夹名称
        new_folder_name = f"{folder}_{id_content}"
        
        # 重命名文件夹
        os.rename(folder, new_folder_name)

